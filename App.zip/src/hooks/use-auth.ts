export { useAuthContext as useAuth } from '@/context/auth-context';

export const ITF = 0.00005; // 0.005%

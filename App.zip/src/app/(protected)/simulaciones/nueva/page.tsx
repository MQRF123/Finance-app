"use client";

import { useMemo, useState } from "react";
import { useForm, type Resolver } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Check } from "lucide-react";
import { schema, defaultVals, type FormValues } from "./form-schema";

// 👇 NUEVO: Firestore + auth
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/hooks/use-auth";

const resolver = zodResolver(schema) as unknown as Resolver<FormValues>;

const INPUT_CLS =
  "w-full rounded-xl border px-3 py-2 bg-white focus:outline-none focus:ring-2 ring-emerald-200";

function Field({ label, error, children }: { label: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="text-sm">
      {label}
      <div className="mt-1">{children}</div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </label>
  );
}

function tasaMensual(tipo: "TEA" | "TNA", valor: number, cap: number) {
  if (tipo === "TEA") return Math.pow(1 + valor, 1 / 12) - 1;
  const iea = Math.pow(1 + valor / cap, cap) - 1;
  return Math.pow(1 + iea, 1 / 12) - 1;
}
function fmtMoney(v: number, moneda: "PEN" | "USD") {
  return new Intl.NumberFormat("es-PE", {
    style: "currency",
    currency: moneda === "PEN" ? "PEN" : "USD",
    minimumFractionDigits: 2,
  }).format(v);
}

export default function NuevaSimulacionPage() {
  const { user } = useAuth(); // 👈 para obtener uid
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [pagoMensual, setPagoMensual] = useState<number | null>(null);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState<string>("");

  const form = useForm<FormValues>({
    resolver,
    defaultValues: defaultVals,
    mode: "onTouched",
  });

  const moneda = form.watch("moneda");
  const simbolo = useMemo(() => (moneda === "PEN" ? "S/" : "US$"), [moneda]);
  const errors = form.formState.errors;

  const groupKeys: Record<1 | 2 | 3 | 4, (keyof FormValues)[]> = {
    1: ["dni", "nombres", "estadoCivil", "ingresoMensual", "dependientes", "email", "telefono"],
    2: ["tipoInmueble", "departamento", "proyecto", "precioVenta"],
    3: ["tasaValor", "plazoMeses", "cuotaInicial"],
    4: [],
  };

  const onNext = async () => {
    const ok = await form.trigger(groupKeys[step], { shouldFocus: true });
    if (!ok) return;
    setStep((s) => (Math.min(4, s + 1) as 1 | 2 | 3 | 4));
  };
  const onBack = () => setStep((s) => (Math.max(1, s - 1) as 1 | 2 | 3 | 4));

  // === Cálculo (como lo tenías)
  const onCalcular = async () => {
    const ok = await form.trigger(
      ["tasaValor", "plazoMeses", "precioVenta", "cuotaInicial", "bbp", "bbpMonto", "bonoVerde", "bonoVerdeMonto"],
      { shouldFocus: true }
    );
    if (!ok) return;

    const v = form.getValues();
    const bonos = (v.bbp ? v.bbpMonto : 0) + (v.bonoVerde ? v.bonoVerdeMonto : 0);
    const principal = Math.max(0, v.precioVenta - v.cuotaInicial - bonos);
    const i = tasaMensual(v.tipoTasa, v.tasaValor, v.capitalizacion);
    const f = Math.pow(1 + i, v.plazoMeses);
    const cuotaBase = i > 0 ? (principal * i * f) / (f - 1) : principal / v.plazoMeses;
    const cuota = cuotaBase + (v.desgravamenMensualSoles || 0);

    setPagoMensual(cuota);
    setStep(4);
  };

  // === GUARDAR EN FIRESTORE ===
  const onGuardar = async () => {
    setSaveMsg("");
    if (!user) {
      setSaveMsg("Debes iniciar sesión para guardar.");
      return;
    }

    const v = form.getValues();
    // principal financiado neto (precio - inicial - bonos)
    const bonos = (v.bbp ? v.bbpMonto : 0) + (v.bonoVerde ? v.bonoVerdeMonto : 0);
    const monto = Math.max(0, v.precioVenta - v.cuotaInicial - bonos);

    // TCEA aproximada: a partir de tasa mensual (si deseas, luego la cambias por tu TCEA real)
    const i = tasaMensual(v.tipoTasa, v.tasaValor, v.capitalizacion);
    const tea = Math.pow(1 + i, 12) - 1; // efectiva anual
    const tceaAprox = tea; // reemplaza por tu cálculo de TCEA real cuando lo tengas

    setSaving(true);
    try {
      await addDoc(collection(db, "simulaciones"), {
        userId: user.uid,
        createdAt: serverTimestamp(),
        // datos clave para dashboard/historial
        tcea: tceaAprox,            // proporción (0.1325)
        plazoMeses: v.plazoMeses,
        monto,
        moneda: v.moneda,
        nombre: v.proyecto || v.nombres || null,
        estado: "En proceso",

        // si quieres, guarda todo el formulario:
        form: v,
      });
      setSaveMsg("✔ Simulación guardada. La verás en Dashboard e Historial.");
    } catch (e: any) {
      console.error(e);
      setSaveMsg(e?.message ?? "Error al guardar.");
    } finally {
      setSaving(false);
    }
  };

  const blockInvalidNumber = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "-" || e.key === "+" || e.key === "e" || e.key === "E") e.preventDefault();
  };
  const blurOnWheel = (e: React.WheelEvent<HTMLInputElement>) => {
    (e.currentTarget as HTMLInputElement).blur();
  };

  // … (tu JSX de pasos 1, 2 y 3 queda igual) …

  // === Paso 4 (Resultados) ===
  return (
    <section>
      {/* …tu layout/aside como ya lo tenías… */}
      {/* Dentro del contenedor principal, reemplaza el bloque del paso 4 por esto: */}
      {step === 4 && (
        <div className="grid place-items-center">
          <div className="w-full max-w-md bg-emerald-50 rounded-xl p-4 border">
            <div className="rounded-lg bg-emerald-700 text-white text-center py-2 font-semibold">Resultados</div>

            <div className="text-center py-5">
              <div className="text-3xl font-bold text-emerald-800">
                {pagoMensual != null ? fmtMoney(pagoMensual, form.getValues().moneda) : "—"}
              </div>
              <div className="text-sm text-neutral-700">Pago mensual (aprox.)</div>
            </div>

            <div className="bg-white rounded-lg border p-3 text-sm space-y-1">
              {/* datos resumidos */}
              {/* ... puedes conservar los RowKV que ya tenías ... */}
            </div>

            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={onGuardar}
                disabled={saving}
                className="flex-1 rounded-lg bg-emerald-700 text-white px-4 py-2 text-sm hover:bg-emerald-800 disabled:opacity-50"
              >
                {saving ? "Guardando…" : "Guardar simulación"}
              </button>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="rounded-lg border px-4 py-2 text-sm"
              >
                Nueva
              </button>
            </div>

            {saveMsg && <p className="mt-2 text-xs text-neutral-700">{saveMsg}</p>}
          </div>
        </div>
      )}
    </section>
  );
}

"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  collection,
  onSnapshot,
  orderBy,
  query,
  where,
  Timestamp,
  type DocumentData,
  type QueryDocumentSnapshot,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/hooks/use-auth";

type Moneda = "PEN" | "USD";
type Estado = "Aprobado" | "Rechazado" | "En proceso" | undefined;

type Simulacion = {
  id: string;
  userId: string;
  createdAt: Timestamp | Date;
  tcea: number;         // proporción (0.1325 => 13.25%)
  plazoMeses: number;
  monto: number;
  moneda?: Moneda;
  nombre?: string;
  estado?: Estado;
};

function toSimulacion(d: QueryDocumentSnapshot<DocumentData>): Simulacion {
  const x = d.data();
  const createdAt =
    x.createdAt instanceof Timestamp
      ? x.createdAt
      : typeof x.createdAt === "number"
      ? new Date(x.createdAt)
      : new Date();
  return {
    id: d.id,
    userId: String(x.userId ?? ""),
    createdAt,
    tcea: Number(x.tcea ?? 0),
    plazoMeses: Number(x.plazoMeses ?? 0),
    monto: Number(x.monto ?? 0),
    moneda: (x.moneda as Moneda) ?? "PEN",
    nombre: typeof x.nombre === "string" ? x.nombre : undefined,
    estado: typeof x.estado === "string" ? (x.estado as Estado) : undefined,
  };
}

function fmtMoney(v: number, m: Moneda = "PEN") {
  return new Intl.NumberFormat("es-PE", {
    style: "currency",
    currency: m === "USD" ? "USD" : "PEN",
    minimumFractionDigits: 2,
  }).format(v);
}

export default function SimulacionesPage() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Simulacion[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    if (!user) return;
    setLoading(true);
    setErr("");

    const col = collection(db, "simulaciones");
    // Requiere índice: userId ASC + createdAt DESC
    const qy = query(col, where("userId", "==", user.uid), orderBy("createdAt", "desc"));

    const unsub = onSnapshot(
      qy,
      (snap) => {
        setRows(snap.docs.map(toSimulacion));
        setLoading(false);
      },
      (e) => {
        console.error(e);
        setErr(
          e?.message?.includes("insufficient permissions")
            ? "No tienes permisos para leer simulaciones. Revisa tus Reglas de Firestore."
            : e?.message ?? "Error al leer datos"
        );
        setLoading(false);
      }
    );
    return () => unsub();
  }, [user]);

  const tieneDatos = useMemo(() => rows.length > 0, [rows]);

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Simulaciones</h1>
          <p className="text-sm text-neutral-600">Lista de simulaciones guardadas</p>
        </div>
        <Link
          href="/simulaciones/nueva"
          className="rounded-lg bg-emerald-700 text-white px-3 py-2 text-sm hover:bg-emerald-800"
        >
          Nueva simulación
        </Link>
      </div>

      {err && (
        <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {err}
        </div>
      )}

      {/* Estado vacío / carga */}
      {loading && !tieneDatos && (
        <div className="rounded-2xl border bg-white p-6 text-sm text-neutral-600">
          Cargando…
        </div>
      )}

      {!loading && !tieneDatos && (
        <div className="rounded-2xl border bg-white p-8 text-center">
          <p className="text-sm text-neutral-700">Aún no tienes simulaciones.</p>
          <Link
            href="/simulaciones/nueva"
            className="inline-block mt-3 rounded-lg bg-emerald-700 text-white px-3 py-2 text-sm hover:bg-emerald-800"
          >
            Crear mi primera simulación
          </Link>
        </div>
      )}

      {/* Tarjetas */}
      {tieneDatos && (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {rows.map((r) => (
            <Link
              key={r.id}
              href={`/simulaciones/${r.id}`}
              className="rounded-2xl border bg-white p-4 hover:shadow-sm transition"
            >
              <div className="text-sm text-neutral-600">
                {r.nombre ?? `Simulación #${r.id.slice(0, 6).toUpperCase()}`}
              </div>
              <div className="mt-1 text-2xl font-bold">{fmtMoney(r.monto, r.moneda)}</div>
              <div className="mt-1 text-sm text-neutral-600">
                TCEA {(r.tcea * 100).toFixed(2)}% · {r.plazoMeses}m
              </div>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}

export default function Loading() { return <div className="p-8">Cargando…</div>; }

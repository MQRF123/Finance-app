export default function NotFound() { return <div className="p-8">No encontrado</div>; }
